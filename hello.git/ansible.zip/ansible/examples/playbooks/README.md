Playbook Examples
=================

Playbook examples have moved.

See [the Ansible-Examples repo](https://github.com/ansible/ansible-examples).

